package project;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        AirlineReservationSystem reservationSystem = new AirlineReservationSystem();

        // Add some sample flights
        reservationSystem.addFlight(new Flight("AA101", "American Airlines", 100));
        reservationSystem.addFlight(new Flight("DL202", "Delta Air Lines", 150));
        reservationSystem.addFlight(new Flight("UA303", "United Airlines", 120));

        while (true) {
            System.out.println("Welcome to the Airline Reservation System");
            System.out.println("1. View Available Flights");
            System.out.println("2. Book a Seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice:\n ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (choice) {
                case 1:
                    System.out.println("Available Flights:");
                    for (Flight flight : reservationSystem.flights) {
                        System.out.println(flight.getFlightNumber() + " - " + flight.getAirline() +
                                " (" + flight.getAvailableSeats() + " seats available)");
                    }
                    break;
                case 2:
                    System.out.print("Enter the flight number: ");
                    String flightNumber = scanner.nextLine();
                    Flight flight = reservationSystem.findFlight(flightNumber);
                    if (flight != null) {
                        System.out.print("Enter the number of seats to book: ");
                        int numSeats = scanner.nextInt();
                        scanner.nextLine(); // Consume the newline character
                        if (flight.bookSeat(numSeats)) {
                            System.out.println("Seat's booked successfully!");
                        } else {
                            System.out.println("Sorry, seats are not available.");
                        }
                    } else {
                        System.out.println("Flight not found.");
                    }
                    break;
                case 3:
                    System.out.println("Thank you for using the Airline Reservation System. Goodbye!");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}

