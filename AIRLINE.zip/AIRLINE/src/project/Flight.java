package project;

public class Flight {
    private String flightNumber;
    private String airline;
    private int capacity;
    private int bookedSeats;

    public Flight(String flightNumber, String airline, int capacity) {
        this.flightNumber = flightNumber;
        this.airline = airline;
        this.capacity = capacity;
        this.bookedSeats = 0;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public String getAirline() {
        return airline;
    }

    public int getAvailableSeats() {
        return capacity - bookedSeats;
    }

    public boolean bookSeat(int numSeats) {
        if (numSeats > 0 && numSeats <= getAvailableSeats()) {
            bookedSeats += numSeats;
            return true;
        }
        return false;
    }
}

