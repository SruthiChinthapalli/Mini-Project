package project;
import java.util.ArrayList;
import java.util.Scanner;

public class AirlineReservationSystem {
    ArrayList<Flight> flights;

    public AirlineReservationSystem() {
        flights = new ArrayList<>();
    }

    public void addFlight(Flight flight) {
        flights.add(flight);
    }

    public Flight findFlight(String flightNumber) {
        for (Flight flight : flights) {
            if (flight.getFlightNumber().equals(flightNumber)) {
                return flight;
            }
        }
        return null;
    }
}

